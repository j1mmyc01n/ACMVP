
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// apps/web/netlify/functions/request-crn.mjs
import { createClient } from "@supabase/supabase-js";
var json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { "Content-Type": "application/json" }
});
var resolveSupabaseUrl = () => {
  const candidates = [
    Netlify.env.get("SUPABASE_URL"),
    Netlify.env.get("VITE_SUPABASE_URL"),
    Netlify.env.get("SUPABASE_DATABASE_URL")
  ];
  for (const raw of candidates) {
    if (!raw)
      continue;
    try {
      const u = new URL(raw);
      if (/\.supabase\.(co|in)$/i.test(u.hostname))
        return `${u.protocol}//${u.host}`;
    } catch {
    }
  }
  return "https://amfikpnctfgesifwdkkd.supabase.co";
};
var generateCRN = (prefix = "CRN", now = /* @__PURE__ */ new Date()) => {
  const y = now.getFullYear(), mo = now.getMonth() + 1, d = now.getDate();
  const hh = String(now.getHours()).padStart(2, "0"), mm = String(now.getMinutes()).padStart(2, "0");
  const leap = y % 4 === 0 && y % 100 !== 0 || y % 400 === 0;
  const dim = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let doy = d;
  for (let i = 0; i < mo - 1; i++)
    doy += dim[i];
  const C = Math.floor(y / 100) - 19, YY = String(y % 100).padStart(2, "0"), DDD = String(doy).padStart(3, "0");
  const sfx = Math.floor(Math.random() * 1296).toString(36).padStart(2, "0").toUpperCase();
  const safePrefix = prefix.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "CRN";
  return `${safePrefix}-${C}${YY}${DDD}-${hh}${mm}-${sfx}`;
};
var LEGAL_VERSIONS = {
  legal_bundle: "v1.0",
  privacy: "v1.0",
  terms: "v1.0",
  medical_disclaimer: "v1.0",
  ai_disclosure: "v1.0",
  crisis_notice: "v1.0",
  cookie_policy: "v1.0"
};
var COMBINED_AGREEMENT_VERSION = `terms-${LEGAL_VERSIONS.terms}-privacy-${LEGAL_VERSIONS.privacy}-medical-${LEGAL_VERSIONS.medical_disclaimer}`;
var haversineKm = (a, b) => {
  const toRad = (deg) => deg * Math.PI / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
};
var pickClosestCentre = (centres, origin) => {
  const usable = centres.filter((c) => typeof c.latitude === "number" && typeof c.longitude === "number");
  if (!usable.length)
    return centres[0] || null;
  if (!origin)
    return usable[0];
  let best = null;
  for (const c of usable) {
    const d = haversineKm(origin, { lat: c.latitude, lng: c.longitude });
    if (!best || d < best.d)
      best = { row: c, d };
  }
  return best?.row || null;
};
var request_crn_default = async (req, _context) => {
  if (req.method === "GET") {
    return json(200, { ok: true, function: "request-crn", method: "POST to request a CRN" });
  }
  if (req.method !== "POST") {
    return json(405, { ok: false, error: "Method not allowed" });
  }
  const SERVICE_KEY = Netlify.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SERVICE_KEY) {
    return json(500, { ok: false, error: "SUPABASE_SERVICE_ROLE_KEY not configured" });
  }
  const SUPABASE_URL = resolveSupabaseUrl();
  const supabase = createClient(SUPABASE_URL, SERVICE_KEY, {
    auth: { persistSession: false }
  });
  let body;
  try {
    body = await req.json();
  } catch {
    return json(400, { ok: false, error: "Invalid JSON body" });
  }
  const first_name = (body.first_name || "").trim();
  const mobile = (body.mobile || "").trim();
  const email = (body.email || "").trim().toLowerCase();
  const assistance_type = (body.assistance_type || "").trim().toLowerCase() || null;
  if (!first_name) {
    return json(400, { ok: false, error: "First name is required" });
  }
  if (!mobile && !email) {
    return json(400, {
      ok: false,
      error: "Please provide either a mobile number or an email address"
    });
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return json(400, { ok: false, error: "Please enter a valid email address" });
  }
  const ip = req.headers.get("x-forwarded-for") || req.headers.get("x-nf-client-connection-ip") || null;
  const device_info = body.device_info || { source: "request-crn" };
  const location = body.location && typeof body.location.lat === "number" && typeof body.location.lng === "number" ? { lat: body.location.lat, lng: body.location.lng } : null;
  let careCentre = null;
  let careCentreDistanceKm = null;
  let unmatchedAssistanceType = false;
  let typeMatchPool = [];
  try {
    const { data: centres } = await supabase.from("care_centres_1777090000").select("id, name, suffix, address, phone, status, active, latitude, longitude, service_types");
    const eligible = (centres || []).filter((c) => (c.active === void 0 || c.active === null || c.active) && (!c.status || c.status === "active"));
    if (assistance_type) {
      typeMatchPool = eligible.filter((c) => {
        const types = Array.isArray(c.service_types) ? c.service_types : [];
        return types.some((t) => String(t).toLowerCase() === assistance_type);
      });
    }
    if (assistance_type && typeMatchPool.length === 0) {
      unmatchedAssistanceType = true;
      careCentre = pickClosestCentre(eligible, location);
    } else {
      const pool = typeMatchPool.length ? typeMatchPool : eligible;
      careCentre = pickClosestCentre(pool, location);
    }
    if (careCentre && location && typeof careCentre.latitude === "number" && typeof careCentre.longitude === "number") {
      careCentreDistanceKm = Number(haversineKm(location, {
        lat: careCentre.latitude,
        lng: careCentre.longitude
      }).toFixed(2));
    }
  } catch (_) {
    careCentre = null;
  }
  const careCentreName = careCentre?.name || null;
  const crnPrefix = careCentre?.suffix?.toUpperCase() || "CRN";
  const crn = generateCRN(crnPrefix);
  const warnings = [];
  const requestPayload = {
    first_name,
    mobile,
    email,
    status: "processed",
    crn_issued: crn
  };
  if (assistance_type)
    requestPayload.assistance_type = assistance_type;
  const requestInsert = await supabase.from("crn_requests_1777090006").insert([requestPayload]).select().single();
  if (requestInsert.error)
    warnings.push(`crn_requests: ${requestInsert.error.message}`);
  const crnInsert = await supabase.from("crns_1740395000").insert([{ code: crn, is_active: true }]).select().single();
  if (crnInsert.error)
    warnings.push(`crns: ${crnInsert.error.message}`);
  const clientPayload = {
    name: first_name,
    email: email || null,
    phone: mobile || null,
    crn,
    status: "active",
    support_category: assistance_type || "general"
  };
  if (careCentreName)
    clientPayload.care_centre = careCentreName;
  const clientInsert = await supabase.from("clients_1777020684735").insert([clientPayload]).select().single();
  if (clientInsert.error)
    warnings.push(`clients: ${clientInsert.error.message}`);
  const client = clientInsert.data || null;
  const auditInsert = await supabase.from("profile_audit_log").insert({
    profile_id: client?.id || null,
    crn,
    action: "CRN_CREATED",
    agreement_accepted: true,
    agreement_text: "By using Acute Connect, the user agreed to all platform legal documents and consented to proceed.",
    legal_bundle_version: LEGAL_VERSIONS.legal_bundle,
    privacy_version: LEGAL_VERSIONS.privacy,
    terms_version: LEGAL_VERSIONS.terms,
    medical_disclaimer_version: LEGAL_VERSIONS.medical_disclaimer,
    ai_disclosure_version: LEGAL_VERSIONS.ai_disclosure,
    crisis_notice_version: LEGAL_VERSIONS.crisis_notice,
    cookie_policy_version: LEGAL_VERSIONS.cookie_policy,
    device_info,
    ip_address: ip
  });
  if (auditInsert.error)
    warnings.push(`profile_audit_log: ${auditInsert.error.message}`);
  if (careCentre && client?.id) {
    await supabase.from("profile_audit_log").insert({
      profile_id: client.id,
      crn,
      action: "CARE_CENTRE_ASSIGNED",
      agreement_accepted: null,
      device_info: {
        care_centre_id: careCentre.id || null,
        care_centre_name: careCentre.name,
        care_centre_suffix: careCentre.suffix || null,
        distance_km: careCentreDistanceKm,
        routed_automatically: true,
        unmatched_assistance_type: unmatchedAssistanceType
      },
      ip_address: ip
    });
    const routingNote = {
      type: "care_centre_assigned",
      ts: (/* @__PURE__ */ new Date()).toISOString(),
      note: `CRN ${crn} routed to ${careCentre.name}${careCentreDistanceKm != null ? ` (~${careCentreDistanceKm} km)` : ""}${unmatchedAssistanceType ? " (fallback \u2014 no specialist centre for requested type)" : ""}.`,
      care_centre: careCentre.name,
      care_centre_suffix: careCentre.suffix || null
    };
    const { data: existingClient } = await supabase.from("clients_1777020684735").select("event_log").eq("id", client.id).maybeSingle();
    const prevLog = Array.isArray(existingClient?.event_log) ? existingClient.event_log : [];
    const newLog = [routingNote, ...prevLog].slice(0, 200);
    await supabase.from("clients_1777020684735").update({ event_log: newLog }).eq("id", client.id);
  }
  const profileInsert = await supabase.from("profiles").insert([
    {
      full_name: first_name,
      email: email || null,
      phone: mobile || null,
      crn,
      role: "user"
    }
  ]).select().single();
  if (profileInsert.error)
    warnings.push(`profiles: ${profileInsert.error.message}`);
  const profile = profileInsert.data || null;
  const userId = profile?.user_id || profile?.id || null;
  await supabase.from("consent_agreements").insert({
    user_id: userId,
    agreement_type: "platform_use_and_medical_disclaimer",
    agreement_version: COMBINED_AGREEMENT_VERSION,
    accepted: true,
    source_action: "create_crn",
    ip_address: ip,
    device_info
  });
  const crnRecord = await supabase.from("crn_records").insert([{ crn, user_id: userId, status: "active", created_by: userId }]).select().single();
  if (crnRecord.error)
    warnings.push(`crn_records: ${crnRecord.error.message}`);
  await supabase.from("audit_logs").insert({
    user_id: userId,
    action: "CREATE_CRN",
    entity_type: "crn_records",
    entity_id: crnRecord.data?.id || null,
    previous_value: null,
    new_value: {
      ...crnRecord.data || { crn },
      care_centre: careCentreName,
      care_centre_id: careCentre?.id || null,
      approximate_location: location,
      distance_km: careCentreDistanceKm
    },
    agreement_version: COMBINED_AGREEMENT_VERSION,
    ip_address: ip,
    device_info
  });
  if (profile) {
    const fhirPatient = {
      resourceType: "Patient",
      id: crn,
      identifier: [{ system: "https://acuteconnect.health/crn", value: crn }],
      name: [{ text: first_name }],
      telecom: [
        ...mobile ? [{ system: "phone", value: mobile }] : [],
        ...email ? [{ system: "email", value: email }] : []
      ],
      managingOrganization: careCentreName ? { display: careCentreName, identifier: { value: careCentre?.suffix || careCentreName } } : void 0,
      active: true
    };
    await supabase.from("medical_events").insert({
      user_id: userId,
      crn,
      event_type: "patient_created",
      fhir_resource_type: "Patient",
      fhir_payload: fhirPatient
    });
  }
  if (unmatchedAssistanceType) {
    const reportInsert = await supabase.from("sysadmin_reports_1777100012").insert({
      report_type: "unmatched_assistance_type",
      severity: "high",
      title: `No active centre offers "${assistance_type}" \u2014 CRN ${crn} routed to nearest support centre`,
      related_crn: crn,
      details: {
        requested_assistance_type: assistance_type,
        fallback_care_centre: careCentre ? { id: careCentre.id, name: careCentre.name, suffix: careCentre.suffix } : null,
        fallback_distance_km: careCentreDistanceKm,
        approximate_location: location,
        first_name,
        contact: { mobile: mobile || null, email: email || null },
        ip_address: ip
      }
    });
    if (reportInsert.error)
      warnings.push(`sysadmin_reports: ${reportInsert.error.message}`);
  }
  return json(200, {
    ok: true,
    crn,
    profile,
    legacy_client: client,
    care_centre: careCentre ? {
      id: careCentre.id,
      name: careCentre.name,
      suffix: careCentre.suffix,
      address: careCentre.address,
      phone: careCentre.phone,
      distance_km: careCentreDistanceKm,
      service_types: careCentre.service_types || []
    } : null,
    assistance_type,
    unmatched_assistance_type: unmatchedAssistanceType,
    warnings: warnings.length ? warnings : void 0
  });
};
var config = {
  path: "/api/crn"
};
export {
  config,
  request_crn_default as default
};
