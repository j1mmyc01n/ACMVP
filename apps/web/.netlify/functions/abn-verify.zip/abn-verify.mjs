
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// apps/web/netlify/functions/abn-verify.mjs
var json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
});
var abn_verify_default = async (req, _context) => {
  if (req.method === "OPTIONS")
    return json({}, 200);
  if (req.method !== "POST")
    return json({ error: "Method Not Allowed" }, 405);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }
  const abn = (body.abn || "").replace(/\s/g, "");
  if (!abn)
    return json({ error: "ABN required" }, 400);
  const guid = process.env.ABN_API_GUID;
  if (!guid) {
    return json({ status: "manual", message: "Will be verified manually" });
  }
  try {
    const url = `https://api.abn.business.gov.au/abn/v3/abn?abn=${encodeURIComponent(abn)}&guid=${guid}&includeHistoricalDetails=N`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8e3) });
    if (!res.ok)
      return json({ status: "manual", message: "Will be verified manually" });
    const data = await res.json();
    if (data?.Abn && data?.EntityName) {
      return json({ status: "valid", businessName: data.EntityName, abn: data.Abn });
    }
    return json({ status: "invalid", message: "Not found" });
  } catch {
    return json({ status: "manual", message: "Will be verified manually" });
  }
};
export {
  abn_verify_default as default
};
