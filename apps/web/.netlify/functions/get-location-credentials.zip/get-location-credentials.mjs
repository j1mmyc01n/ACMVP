
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// apps/web/netlify/functions/get-location-credentials.mjs
var SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || "";
var SUPABASE_SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
var json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "content-type, authorization"
  }
});
var get_location_credentials_default = async (req, _ctx) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "content-type, authorization"
      }
    });
  }
  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE) {
    return json({ error: "Supabase environment not configured" }, 503);
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }
  const { location_id, credential_type } = body;
  if (!location_id || !credential_type) {
    return json({ error: "location_id and credential_type are required" }, 400);
  }
  const res = await fetch(`${SUPABASE_URL}/rest/v1/location_credentials?location_id=eq.${encodeURIComponent(location_id)}&credential_type=eq.${encodeURIComponent(credential_type)}&select=id,service_name`, {
    headers: {
      "apikey": SUPABASE_SERVICE_ROLE,
      "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE}`
    }
  });
  if (!res.ok) {
    const text = await res.text();
    return json({ error: `Supabase error: ${text}` }, 502);
  }
  const rows = await res.json();
  const row = rows[0] ?? null;
  return json({
    exists: !!row,
    service_name: row?.service_name ?? null
  });
};
var config = { path: "/api/get-location-credentials" };
export {
  config,
  get_location_credentials_default as default
};
